# 3-Modes-TivaC
Design a simple calculator with 2 extra features: a timer and a stopwatch. The calculator shall do the basic operations that are addition, subtraction, multiplication, and division. The timer and stopwatch features will be both handled separately by the hardware.

In this project you will have 3 main Modes. You will need to have a keypad for all number inputs. You will need a push button to switch 
between these 3 modes. You are free if you need to add more push buttons. 
# 1. Calculator
In this mode you will be asked to take inputs from the user and print that input on the LCD. You will take two numbers (each more than 1 
digit) and a sign between them. Use the keypad numbers to get the numbers. 
A button: +
B button: -
C button: /
D button: =
* button: x
Print the numbers and the sign on the LCD before printing the result. 
# 2. Timer Mode
 In this mode the user will set a time using the keypad, the timer will start counting down and as soon as it reaches the time zero it will 
trigger a buzzer.
 When you switch to this mode initially present 00:00 on the LCD then take the input from the user as minutes and seconds. Write the 
input as minutes and seconds then start the timer as soon as the user presses on the D button on the keypad.
# 3. Stopwatch Mode
 In this mode the user will be using three buttons, one to start the stopwatch, one to pause the stopwatch, and one to reset the value 
back to 00:00.
 When you switch to this mode initially present 00:00 on the LCD. Whenever the user presses on the start button start incrementing the 
stopwatch. 
