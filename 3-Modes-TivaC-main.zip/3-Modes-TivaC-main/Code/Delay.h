/**************************************************
*  @file     Delay.h
*
*  @author   Group Alpha
*
*  @date     2/12/2018 3:30 PM
*
**************************************************/
#ifndef __Delay_H__
#define __Delay_H__

void delay_ms(long time);
void delay_us(long time);

#endif